<?php
/**
 * REST Controller — LMS Cursos, Lecciones y Matrículas (Fase 11)
 *
 * Namespace: atora-lms/v1
 *
 * GET  /atora-lms/v1/courses                → lista
 * GET  /atora-lms/v1/courses/{id}           → curso con curriculum
 * POST /atora-lms/v1/courses                → crear
 * POST /atora-lms/v1/courses/{id}           → actualizar
 * GET  /atora-lms/v1/courses/{id}/stats     → estadísticas de estudiantes
 * POST /atora-lms/v1/courses/{id}/enroll    → matricular usuario
 * GET  /atora-lms/v1/courses/{id}/progress  → progreso del usuario actual
 * POST /atora-lms/v1/lessons/{id}/complete  → completar lección
 * GET  /atora-lms/v1/migration/status       → estado de migración CPTs
 * POST /atora-lms/v1/migration/run          → ejecutar migración (admin)
 *
 * @package ATORA_LMS\LMS
 * @since   5.29.0
 */

namespace ATORA\LMS;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class LMS_REST_Controller {

	const REST_NAMESPACE = 'atora-lms/v1';

	public static function register_routes(): void {
		$ns       = self::REST_NAMESPACE;
		$can_read = array( __CLASS__, 'can_read' );
		$can_inst = array( __CLASS__, 'can_manage_courses' );
		$can_admin = array( __CLASS__, 'can_admin' );

		register_rest_route( $ns, '/courses', array(
			array( 'methods' => 'GET',  'callback' => array( __CLASS__, 'list_courses' ),  'permission_callback' => $can_read ),
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'create_course' ), 'permission_callback' => $can_inst ),
		) );
		register_rest_route( $ns, '/courses/(?P<course_id>\d+)', array(
			array( 'methods' => 'GET',  'callback' => array( __CLASS__, 'get_course' ),    'permission_callback' => $can_read ),
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'update_course' ), 'permission_callback' => $can_inst ),
		) );
		register_rest_route( $ns, '/courses/(?P<course_id>\d+)/stats', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'course_stats' ), 'permission_callback' => $can_inst,
		) );
		register_rest_route( $ns, '/courses/(?P<course_id>\d+)/enroll', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'enroll' ), 'permission_callback' => $can_inst,
		) );
		register_rest_route( $ns, '/courses/(?P<course_id>\d+)/progress', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'get_progress' ), 'permission_callback' => 'is_user_logged_in',
		) );
		register_rest_route( $ns, '/lessons/(?P<lesson_id>\d+)/complete', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'complete_lesson' ), 'permission_callback' => 'is_user_logged_in',
		) );
		register_rest_route( $ns, '/lessons/(?P<lesson_id>\d+)', array(
			array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'update_lesson' ), 'permission_callback' => $can_inst ),
		) );
		register_rest_route( $ns, '/migration/status', array(
			'methods' => 'GET', 'callback' => array( __CLASS__, 'migration_status' ), 'permission_callback' => $can_admin,
		) );
		register_rest_route( $ns, '/migration/run', array(
			'methods' => 'POST', 'callback' => array( __CLASS__, 'run_migration' ), 'permission_callback' => $can_admin,
		) );
		// Fase II S6 — Vista de cohorte
		register_rest_route( $ns, '/courses/(?P<course_id>\d+)/cohort', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'cohort' ),
			'permission_callback' => $can_inst,
		) );
	}

	// ── Permisos ─────────────────────────────────────────────────────────────

	public static function can_read(): bool {
		return is_user_logged_in();
	}

	public static function can_manage_courses(): bool {
		return current_user_can( 'clms_manage_courses' ) || current_user_can( 'manage_options' );
	}

	public static function can_admin(): bool {
		return current_user_can( 'manage_options' );
	}

	/**
	 * PT-1 (6.5.2): propiedad de recurso para el LMS de tablas — mismo
	 * patrón jerárquico que CLMS_Access::can_manage_resource_context()
	 * ya usa para el LMS legado de posts (admin → propietario →
	 * edit_others_lm_courses → false), portado a atora_courses.
	 * instructor_id en vez de post_author. Fail closed: curso
	 * inexistente no es "permitido".
	 *
	 * permission_callback ($can_inst) no tiene acceso al course_id de
	 * la ruta con la firma actual — se verifica al inicio de cada
	 * callback en vez de en el registro de la ruta.
	 *
	 * @param int $course_id
	 * @return bool
	 */
	private static function can_manage_this_course( int $course_id ): bool {
		if ( current_user_can( 'manage_options' ) ) {
			return true;
		}
		if ( current_user_can( 'edit_others_lm_courses' ) ) {
			return true;
		}

		$course = LMS_Course_Service::get( $course_id );
		if ( ! $course ) {
			return false;
		}

		return current_user_can( 'clms_manage_courses' )
			&& (int) ( $course['instructor_id'] ?? 0 ) === get_current_user_id();
	}

	private static function can_manage_this_lesson( int $lesson_id ): bool {
		$lesson = LMS_Course_Service::get_lesson( $lesson_id );
		if ( ! $lesson ) {
			return false;
		}
		$course_id = absint( $lesson['course_id'] ?? 0 );
		if ( ! $course_id ) {
			return false;
		}
		return self::can_manage_this_course( $course_id );
	}

	private static function error_response( \WP_Error $error, int $fallback_status = 400 ): \WP_REST_Response {
		$data = $error->get_error_data();
		$status = is_array( $data ) && isset( $data['status'] ) ? absint( $data['status'] ) : $fallback_status;
		$status = $status ?: $fallback_status;
		return new \WP_REST_Response(
			array( 'success' => false, 'message' => $error->get_error_message() ),
			$status
		);
	}

	/**
	 * @return \WP_REST_Response
	 */
	private static function forbidden_course_response(): \WP_REST_Response {
		return new \WP_REST_Response(
			array( 'success' => false, 'message' => __( 'No tienes permisos sobre este curso.', 'atora-lms' ) ),
			403
		);
	}

	// ── Cursos ───────────────────────────────────────────────────────────────

	public static function list_courses( \WP_REST_Request $r ): \WP_REST_Response {
		$status        = sanitize_key( (string) ( $r->get_param( 'status' ) ?: 'published' ) );
		$instructor_id = absint( $r->get_param( 'instructor_id' ) ?: 0 );

		// PT-2.1 (6.5.2): status=all o un estado no público (draft,
		// private) no debe llegar sin restricción al servicio — antes
		// se confiaba en que el frontend simplemente no lo pidiera.
		$requests_non_public = 'all' === $status || ! in_array( $status, array( 'published' ), true );
		if ( $requests_non_public && ! current_user_can( 'manage_options' ) && ! current_user_can( 'edit_others_lm_courses' ) ) {
			if ( current_user_can( 'clms_manage_courses' ) ) {
				// Ve sus propios cursos no publicados, no los de nadie más.
				$instructor_id = get_current_user_id();
			} else {
				$status = 'published';
			}
		}

		$args = array(
			'limit'         => absint( $r->get_param( 'limit' ) ?: 20 ),
			'offset'        => absint( $r->get_param( 'offset' ) ?: 0 ),
			'status'        => $status,
			'search'        => sanitize_text_field( (string) ( $r->get_param( 'search' ) ?: '' ) ),
			'instructor_id' => $instructor_id,
			'only_public_legacy_wp_links' => ! self::can_diagnose_broken_legacy_links(),
		);

		$out = LMS_Course_Service::get_all( $args );

		return new \WP_REST_Response( array_merge( array( 'success' => true ), $out ), 200 );
	}

	public static function get_course( \WP_REST_Request $r ): \WP_REST_Response {
		$id     = absint( $r->get_param( 'course_id' ) );
		$course = LMS_Course_Service::get( $id );
		if ( ! $course ) {
			return new \WP_REST_Response( array( 'success' => false, 'message' => __( 'Curso no encontrado.', 'atora-lms' ) ), 404 );
		}

		// PT-2.2/2.3 (6.5.2): 'published' es visible para cualquier
		// logueado, igual que hoy. 'draft'/'private' solo para el
		// propietario, edit_others_lm_courses/manage_options, o —
		// específicamente para 'private', que en este LMS es un espejo
		// directo del post_status nativo de WP (confirmado contra
		// LMS_Migrator: migra 'publish','draft','private' 1:1, no es un
		// estado propio de "acceso restringido a matriculados") — un
		// usuario con read_private_lm_courses, la misma capability que
		// ya cumple ese rol para el LMS legado de posts. El curriculum
		// se adjunta después de este gate, así que sigue la misma
		// regla que el curso — no hay una regla separada que filtrarle.
		if ( ! self::course_is_visible( $course ) ) {
			return new \WP_REST_Response( array( 'success' => false, 'message' => __( 'Curso no encontrado.', 'atora-lms' ) ), 404 );
		}

		$course['curriculum'] = LMS_Course_Service::get_curriculum( $id );
		return new \WP_REST_Response( array( 'success' => true, 'course' => $course ), 200 );
	}

	/**
	 * @param array $course Curso de LMS_Course_Service::get()/get_all().
	 * @return bool
	 */
	private static function course_is_visible( array $course ): bool {
		if ( current_user_can( 'manage_options' ) || current_user_can( 'edit_others_lm_courses' ) ) {
			return true;
		}

		$status = (string) ( $course['status'] ?? '' );
		if ( 'published' === $status ) {
			if ( ! is_user_logged_in() ) {
				return false;
			}
			$wp_course_id = absint( $course['wp_post_id'] ?? 0 );
			if ( $wp_course_id <= 0 ) {
				return true;
			}
			// Si el usuario puede diagnosticar, no ocultar el registro.
			if ( self::can_diagnose_broken_legacy_links() ) {
				return true;
			}
			return LMS_Course_Service::legacy_wp_course_post_is_public( $wp_course_id );
		}

		if ( (int) ( $course['instructor_id'] ?? 0 ) === get_current_user_id() && get_current_user_id() > 0 ) {
			return true;
		}

		if ( 'private' === $status ) {
			return current_user_can( 'read_private_lm_courses' );
		}

		return false;
	}

	private static function can_diagnose_broken_legacy_links(): bool {
		return current_user_can( 'manage_options' )
			|| current_user_can( 'edit_others_lm_courses' )
			|| current_user_can( 'clms_manage_courses' );
	}

	public static function create_course( \WP_REST_Request $r ): \WP_REST_Response {
		$data = $r->get_json_params() ?: array();

		// PT-1.3 (6.5.2): nunca confiar en un instructor_id enviado por
		// el cliente que no sea el propio, salvo capability ampliada —
		// si no, cualquier instructor podría crear un curso "a nombre"
		// de otro (o de nadie), sorteando el gate de propiedad del
		// resto de las rutas desde el origen.
		if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'edit_others_lm_courses' ) ) {
			$data['instructor_id'] = get_current_user_id();
		}
		// PT-1.1/1.3 (6.5.3): wp_post_id es el puente de identidad con
		// el LMS legado (CPT lm_course), no un campo de CRUD genérico —
		// ni siquiera manage_options lo escribe por acá. La única vía
		// es LMS_Course_Service::link_to_legacy_post(), que valida el
		// post_type, el permiso sobre ese post puntual y que no esté
		// ya vinculado a otro curso.
		unset( $data['wp_post_id'] );

		$id = LMS_Course_Service::create( $data );
		if ( ! $id ) {
			return new \WP_REST_Response( array( 'success' => false, 'message' => __( 'El título es obligatorio.', 'atora-lms' ) ), 400 );
		}
		return new \WP_REST_Response( array( 'success' => true, 'course' => LMS_Course_Service::get( $id ) ), 201 );
	}

	public static function update_course( \WP_REST_Request $r ): \WP_REST_Response {
		$id = absint( $r->get_param( 'course_id' ) );
		if ( ! self::can_manage_this_course( $id ) ) {
			return self::forbidden_course_response();
		}

		$data = $r->get_json_params() ?: array();
		// PT-1.2 (6.5.3): sin capability ampliada, tampoco puede
		// reasignar instructor_id — el gate de propiedad verifica quién
		// es dueño hoy, no que pueda transferirse el curso a sí mismo
		// desde otro instructor_id, ni "regalarlo" a uno arbitrario.
		if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'edit_others_lm_courses' ) ) {
			unset( $data['instructor_id'] );
		}
		// PT-1.2/1.3 (6.5.3): wp_post_id nunca vía CRUD genérico, ni
		// siquiera para el propietario legítimo del curso — ver
		// create_course() para el porqué completo.
		unset( $data['wp_post_id'] );

		$result = LMS_Course_Service::update( $id, $data );
		if ( is_wp_error( $result ) ) {
			return self::error_response( $result );
		}
		return new \WP_REST_Response( array( 'success' => true, 'course' => LMS_Course_Service::get( $id ) ), 200 );
	}

	public static function update_lesson( \WP_REST_Request $r ): \WP_REST_Response {
		$lesson_id = absint( $r->get_param( 'lesson_id' ) );
		if ( ! self::can_manage_this_lesson( $lesson_id ) ) {
			return self::forbidden_course_response();
		}

		$data = $r->get_json_params() ?: array();
		unset( $data['wp_post_id'] );
		unset( $data['course_id'] );

		$result = LMS_Course_Service::update_lesson( $lesson_id, $data );
		if ( is_wp_error( $result ) ) {
			return self::error_response( $result );
		}

		$lesson = LMS_Course_Service::get_lesson( $lesson_id );
		if ( $lesson ) {
			LMS_Course_Service::invalidate_curriculum_cache( absint( $lesson['course_id'] ?? 0 ) );
		}

		return new \WP_REST_Response( array( 'success' => true, 'lesson' => $lesson ), 200 );
	}

	public static function course_stats( \WP_REST_Request $r ): \WP_REST_Response {
		$id = absint( $r->get_param( 'course_id' ) );
		if ( ! self::can_manage_this_course( $id ) ) {
			return self::forbidden_course_response();
		}
		return new \WP_REST_Response( array( 'success' => true, 'stats' => LMS_Enrollment_Service::get_course_stats( $id ) ), 200 );
	}

	public static function enroll( \WP_REST_Request $r ): \WP_REST_Response {
		$b         = $r->get_json_params() ?: array();
		$course_id = absint( $r->get_param( 'course_id' ) );
		if ( ! self::can_manage_this_course( $course_id ) ) {
			return self::forbidden_course_response();
		}

		// Evitar crear/espejar matrículas en cursos tabulares publicados cuyo
		// wp_post_id apunta a un CPT en trash o ausente.
		$course = LMS_Course_Service::get( $course_id );
		if ( ! $course ) {
			return new \WP_REST_Response( array( 'success' => false, 'message' => __( 'Curso no encontrado.', 'atora-lms' ) ), 404 );
		}
		$wp_course_id = absint( $course['wp_post_id'] ?? 0 );
		if ( $wp_course_id > 0 && ! LMS_Course_Service::legacy_wp_course_post_is_public( $wp_course_id ) ) {
			return new \WP_REST_Response( array( 'success' => false, 'message' => __( 'El curso no está disponible para matrícula (vínculo WordPress inválido).', 'atora-lms' ) ), 409 );
		}

		$user_id   = absint( $b['user_id'] ?? get_current_user_id() );
		$order_id  = absint( $b['order_id'] ?? 0 );

		if ( ! $user_id ) {
			return new \WP_REST_Response( array( 'success' => false, 'message' => __( 'Se requiere user_id.', 'atora-lms' ) ), 400 );
		}
		$id = LMS_Write_Facade::enroll( $user_id, $course_id, $order_id );
		return $id
			? new \WP_REST_Response( array( 'success' => true, 'enrollment_id' => $id ), 200 )
			: new \WP_REST_Response( array( 'success' => false, 'message' => __( 'No se pudo matricular.', 'atora-lms' ) ), 400 );
	}

	public static function get_progress( \WP_REST_Request $r ): \WP_REST_Response {
		if ( ! is_user_logged_in() ) {
			return new \WP_REST_Response( array( 'success' => false ), 401 );
		}
		$course_id = absint( $r->get_param( 'course_id' ) );
		$user_id   = get_current_user_id();
		return new \WP_REST_Response( array( 'success' => true, 'progress' => LMS_Enrollment_Service::get_progress( $user_id, $course_id ) ), 200 );
	}

	public static function complete_lesson( \WP_REST_Request $r ): \WP_REST_Response {
		if ( ! is_user_logged_in() ) {
			return new \WP_REST_Response( array( 'success' => false, 'message' => 'Login requerido.' ), 401 );
		}
		$lesson_id = absint( $r->get_param( 'lesson_id' ) );
		$user_id   = get_current_user_id();

		// Verificar que la lección existe y obtener course_id
		$lesson = LMS_Course_Service::get_lesson( $lesson_id );
		if ( ! $lesson ) {
			return new \WP_REST_Response( array( 'success' => false, 'message' => 'Lección no encontrada.' ), 404 );
		}

		// Verificar matrícula activa (P1 audit fix)
		$course_id   = absint( $lesson['course_id'] );
		$enrollment  = LMS_Enrollment_Service::get_enrollment( $user_id, $course_id );
		if ( ! $enrollment || 'active' !== ( $enrollment['status'] ?? '' ) ) {
			return new \WP_REST_Response( array( 'success' => false, 'message' => 'No tienes una matrícula activa en este curso.' ), 403 );
		}

		$ok       = LMS_Enrollment_Service::complete_lesson( $user_id, $lesson_id );
		$progress = $ok ? LMS_Enrollment_Service::get_progress( $user_id, $course_id ) : array();
		return new \WP_REST_Response( array( 'success' => $ok, 'progress' => $progress ), $ok ? 200 : 400 );
	}

	public static function migration_status( \WP_REST_Request $r ): \WP_REST_Response {
		return new \WP_REST_Response( array( 'success' => true, 'status' => LMS_Migrator::get_status() ), 200 );
	}

	public static function run_migration( \WP_REST_Request $r ): \WP_REST_Response {
		$b      = $r->get_json_params() ?: array();
		$batch  = absint( $b['batch'] ?? 30 );
		$result = LMS_Migrator::migrate_all( $batch );
		return new \WP_REST_Response( array( 'success' => true, 'result' => $result, 'status' => LMS_Migrator::get_status() ), 200 );
	}

	// ── GET /courses/{id}/cohort (Fase II S6) ────────────────────────────────

	public static function cohort( \WP_REST_Request $r ): \WP_REST_Response {
		global $wpdb;

		$course_id = absint( $r->get_param( 'course_id' ) );
		if ( ! self::can_manage_this_course( $course_id ) ) {
			return self::forbidden_course_response();
		}
		$limit     = absint( $r->get_param( 'limit' )  ?: 50 );
		$offset    = absint( $r->get_param( 'offset' ) ?: 0 );

		$enroll_table   = $wpdb->prefix . 'atora_enrollments';
		$progress_table = $wpdb->prefix . 'atora_lesson_progress';
		$contacts_table = $wpdb->prefix . 'atora_contacts';
		$followup_table = $wpdb->prefix . 'atora_crm_student_followups';
		$users_table    = $wpdb->users;

		// Datos base desde atora_enrollments (SIN usermeta ni postmeta)
		$rows = (array) $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT
					e.user_id,
					e.progress_pct,
					e.grade,
					e.enrolled_at,
					e.completed_at,
					e.last_activity,
					e.status      AS enroll_status,
					u.display_name,
					(
						SELECT COUNT(*) FROM {$progress_table} lp
						WHERE lp.user_id = e.user_id AND lp.course_id = e.course_id
						  AND lp.status = 'completed'
					) AS completed_lessons,
					c.conversion_score AS score,
					c.id              AS contact_id,
					sf.risk_level
				 FROM {$enroll_table} e
				 LEFT JOIN {$users_table} u  ON u.ID = e.user_id
				 LEFT JOIN {$contacts_table} c ON c.user_id = e.user_id
				 LEFT JOIN {$followup_table} sf ON sf.user_id = e.user_id AND sf.course_id = e.course_id
				 WHERE e.course_id = %d
				 ORDER BY e.progress_pct DESC
				 LIMIT %d OFFSET %d",
				$course_id, $limit, $offset
			),
			ARRAY_A
		);

		$total = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare( "SELECT COUNT(*) FROM {$enroll_table} WHERE course_id = %d", $course_id )
		);

		$items = array_map( function( array $row ): array {
			return array(
				'user_id'           => absint( $row['user_id'] ),
				'display_name'      => sanitize_text_field( (string) ( $row['display_name']   ?? '' ) ),
				'progress_pct'      => absint( $row['progress_pct'] ),
				'completed_lessons' => absint( $row['completed_lessons'] ),
				'grade'             => isset( $row['grade'] ) && $row['grade'] !== null ? (float) $row['grade'] : null,
				'last_activity'     => sanitize_text_field( (string) ( $row['last_activity']  ?? '' ) ),
				'enroll_status'     => sanitize_key(        (string) ( $row['enroll_status']  ?? 'active' ) ),
				'score'             => absint( $row['score'] ?? 0 ),
				'contact_id'        => absint( $row['contact_id'] ?? 0 ),
				'risk_level'        => sanitize_key( (string) ( $row['risk_level'] ?? 'normal' ) ),
			);
		}, $rows );

		return new \WP_REST_Response( array( 'success' => true, 'items' => $items, 'total' => $total ), 200 );
	}
}

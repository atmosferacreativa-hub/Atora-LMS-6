<?php
/**
 * LMS_Course_Service — CRUD de cursos en tablas propias (Fase 11)
 *
 * Coexiste con los CPTs lm_course/lm_lesson durante la transición.
 * El campo wp_post_id permite sincronización bidireccional.
 *
 * @package ATORA_LMS\LMS
 * @since   5.29.0
 */

namespace ATORA\LMS;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class LMS_Course_Service {

	// ── Cursos ───────────────────────────────────────────────────────────────

	public static function get( int $course_id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$wpdb->prefix}atora_courses WHERE id = %d LIMIT 1", $course_id ),
			ARRAY_A
		);
		return $row ? self::format_course( $row ) : null;
	}

	public static function get_by_wp_post( int $wp_post_id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$wpdb->prefix}atora_courses WHERE wp_post_id = %d LIMIT 1", $wp_post_id ),
			ARRAY_A
		);
		return $row ? self::format_course( $row ) : null;
	}

	/**
	 * Valida si el vínculo `wp_post_id` apunta a un CPT `lm_course` publicado.
	 *
	 * Objetivo: evitar exponer cursos tabulares `published` cuyo puente legacy
	 * (CPT) está en `trash` o ya no existe.
	 *
	 * Nota: esto es una validación de visibilidad/enrolabilidad para estudiantes;
	 * NO debe usarse para ocultar el registro a administración.
	 */
	public static function legacy_wp_course_post_is_public( int $wp_post_id ): bool {
		if ( $wp_post_id <= 0 || ! function_exists( 'get_post' ) ) {
			return false;
		}
		$post = get_post( $wp_post_id );
		if ( ! $post ) {
			return false;
		}
		if ( 'lm_course' !== (string) ( $post->post_type ?? '' ) ) {
			return false;
		}
		return 'publish' === (string) ( $post->post_status ?? '' );
	}

	public static function get_all( array $args = array() ): array {
		global $wpdb;

		$table    = $wpdb->prefix . 'atora_courses';
		$limit    = max( 1, min( 200, absint( $args['limit']  ?? 20 ) ) );
		$offset   = absint( $args['offset'] ?? 0 );
		$status   = sanitize_key( (string) ( $args['status'] ?? 'published' ) );
		$search   = sanitize_text_field( (string) ( $args['search'] ?? '' ) );
		$instr_id = absint( $args['instructor_id'] ?? 0 );
		$only_public_legacy_wp_links = ! empty( $args['only_public_legacy_wp_links'] );

		$posts_table = property_exists( $wpdb, 'posts' )
			? (string) $wpdb->posts
			: ( $wpdb->prefix . 'posts' );
		$from  = "{$table} c";
		$joins = '';

		$where  = 'WHERE 1=1';
		$params = array();

		if ( '' !== $status && 'all' !== $status ) {
			$where   .= ' AND c.status = %s';
			$params[] = $status;
		}
		if ( '' !== $search ) {
			$where   .= ' AND (c.title LIKE %s OR c.description LIKE %s)';
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$params[] = $like;
			$params[] = $like;
		}
		if ( $instr_id ) {
			$where   .= ' AND c.instructor_id = %d';
			$params[] = $instr_id;
		}

		// Opción explícita: al listar cursos para estudiantes, excluir
		// cursos tabulares `published` cuyo wp_post_id apunta a un CPT
		// inexistente o no público.
		if ( $only_public_legacy_wp_links ) {
			$joins    .= " LEFT JOIN {$posts_table} p ON p.ID = c.wp_post_id";
			$where    .= ' AND (COALESCE(c.wp_post_id, 0) <= 0 OR (p.ID IS NOT NULL AND p.post_type = %s AND p.post_status = %s))';
			$params[] = 'lm_course';
			$params[] = 'publish';
		}

		$params_c  = $params;
		$count_sql = "SELECT COUNT(*) FROM {$from} {$joins} {$where}";
		$total     = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			! empty( $params_c )
				? $wpdb->prepare( $count_sql, ...$params_c )
				: $count_sql
		);

		$params[] = $limit;
		$params[] = $offset;
		$rows = (array) $wpdb->get_results( // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$wpdb->prepare( "SELECT c.* FROM {$from} {$joins} {$where} ORDER BY c.published_at DESC, c.id DESC LIMIT %d OFFSET %d", ...$params ),
			ARRAY_A
		);

		return array(
			'items' => array_map( array( __CLASS__, 'format_course' ), $rows ),
			'total' => $total,
		);
	}

	/**
	 * PT-6 (6.5.5): create() genérico nunca acepta wp_post_id, sin
	 * importar quién llame ni con qué capability — sigue habiendo un
	 * solo vínculo permitido con el CPT legado: link_to_legacy_post()
	 * (o create_from_legacy(), exclusivo del migrador). Antes de este
	 * sprint, sanitize_course_data() sí lo aceptaba si algún llamador
	 * interno futuro lo pasara — el endpoint REST ya lo filtraba
	 * (unset($data['wp_post_id'])) pero eso dependía de que TODO
	 * llamador hiciera lo mismo; ahora es create() quien lo garantiza,
	 * en un solo lugar.
	 *
	 * @param array $data
	 * @return int
	 */
	public static function create( array $data ): int {
		unset( $data['wp_post_id'] );
		return self::insert_course_row( $data );
	}

	/**
	 * PT-6 (6.5.5): única vía además de link_to_legacy_post() que
	 * puede escribir wp_post_id en un INSERT — exclusiva de
	 * LMS_Migrator, donde wp_post_id es por definición el post legado
	 * que se está migrando, no un valor de entrada externo/REST.
	 *
	 * @param array $data
	 * @return int
	 */
	public static function create_from_legacy( array $data ): int {
		return self::insert_course_row( $data );
	}

	private static function insert_course_row( array $data ): int {
		global $wpdb;
		$row = self::sanitize_course_data( $data );
		if ( '' === ( $row['title'] ?? '' ) ) { return 0; }

		$ok = $wpdb->insert( $wpdb->prefix . 'atora_courses', $row );
		return $ok ? (int) $wpdb->insert_id : 0;
	}

	/**
	 * PT-6 (6.5.5): igual que create() — wp_post_id nunca se acepta
	 * por esta vía genérica, tampoco en update.
	 *
	 * @param int   $course_id
	 * @param array $data
	 * @return bool
	 */
	/**
	 * Actualiza un curso en tablas, incrementando revision exactamente una vez.
	 *
	 * Si el cliente envía `revision`, se interpreta como revision esperada
	 * (optimistic concurrency).
	 *
	 * @param int   $course_id
	 * @param array $data
	 * @return bool|\WP_Error
	 */
	public static function update( int $course_id, array $data ): bool|\WP_Error {
		global $wpdb;
		$expected_revision = absint( $data['revision'] ?? 0 );
		unset( $data['revision'] );
		unset( $data['wp_post_id'] );
		$row = self::sanitize_course_data( $data );
		unset( $row['created_at'] );
		if ( empty( $row ) ) {
			return new \WP_Error( 'atora_course_no_changes', __( 'No se enviaron cambios para guardar.', 'atora-lms' ), array( 'status' => 400 ) );
		}

		$current = $wpdb->get_row(
			$wpdb->prepare( "SELECT id, revision FROM {$wpdb->prefix}atora_courses WHERE id = %d LIMIT 1", $course_id ),
			ARRAY_A
		);
		if ( ! $current ) {
			return new \WP_Error( 'atora_course_not_found', __( 'Curso no encontrado.', 'atora-lms' ), array( 'status' => 404 ) );
		}
		$current_revision = absint( $current['revision'] ?? 1 );
		if ( $expected_revision && $expected_revision !== $current_revision ) {
			return new \WP_Error( 'atora_course_revision_conflict', __( 'El curso cambió. Actualiza antes de guardar.', 'atora-lms' ), array( 'status' => 409 ) );
		}

		$row['revision'] = $current_revision + 1;

		$result = $wpdb->update(
			$wpdb->prefix . 'atora_courses',
			$row,
			array( 'id' => $course_id, 'revision' => $current_revision ),
			null,
			array( '%d', '%d' )
		);

		if ( false === $result ) {
			return new \WP_Error( 'atora_course_update_failed', __( 'No se pudo actualizar.', 'atora-lms' ), array( 'status' => 500 ) );
		}
		if ( 1 !== $result ) {
			return new \WP_Error( 'atora_course_concurrent_update', __( 'No se pudo actualizar porque el curso cambió durante la operación.', 'atora-lms' ), array( 'status' => 409 ) );
		}
		/** 6.28.0: única señal de cambio de contenido (la escucha el registro de cambios). */
		do_action( 'atora/lms/content_revised', 'course', $course_id, $row['revision'] );
		return true;
	}

	/**
	 * Actualiza una lección en tablas, incrementando revision exactamente una vez.
	 *
	 * @param int   $lesson_id
	 * @param array $data
	 * @return bool|\WP_Error
	 */
	public static function update_lesson( int $lesson_id, array $data ): bool|\WP_Error {
		global $wpdb;
		$expected_revision = absint( $data['revision'] ?? 0 );
		unset( $data['revision'] );
		unset( $data['wp_post_id'] );
		$row = self::sanitize_lesson_data( $data );
		unset( $row['created_at'] );
		if ( empty( $row ) ) {
			return new \WP_Error( 'atora_lesson_no_changes', __( 'No se enviaron cambios para guardar.', 'atora-lms' ), array( 'status' => 400 ) );
		}

		$current = $wpdb->get_row(
			$wpdb->prepare( "SELECT id, revision FROM {$wpdb->prefix}atora_lessons WHERE id = %d LIMIT 1", $lesson_id ),
			ARRAY_A
		);
		if ( ! $current ) {
			return new \WP_Error( 'atora_lesson_not_found', __( 'Lección no encontrada.', 'atora-lms' ), array( 'status' => 404 ) );
		}
		$current_revision = absint( $current['revision'] ?? 1 );
		if ( $expected_revision && $expected_revision !== $current_revision ) {
			return new \WP_Error( 'atora_lesson_revision_conflict', __( 'La lección cambió. Actualiza antes de guardar.', 'atora-lms' ), array( 'status' => 409 ) );
		}

		$row['revision'] = $current_revision + 1;

		$result = $wpdb->update(
			$wpdb->prefix . 'atora_lessons',
			$row,
			array( 'id' => $lesson_id, 'revision' => $current_revision ),
			null,
			array( '%d', '%d' )
		);
		if ( false === $result ) {
			return new \WP_Error( 'atora_lesson_update_failed', __( 'No se pudo actualizar.', 'atora-lms' ), array( 'status' => 500 ) );
		}
		if ( 1 !== $result ) {
			return new \WP_Error( 'atora_lesson_concurrent_update', __( 'No se pudo actualizar porque la lección cambió durante la operación.', 'atora-lms' ), array( 'status' => 409 ) );
		}
		do_action( 'atora/lms/content_revised', 'lesson', $lesson_id, $row['revision'] );
		return true;
	}

	/**
	 * PT-1.3 (6.5.3): única vía de escritura de wp_post_id fuera del
	 * migrador — el CRUD genérico (create()/update()) ya no acepta ese
	 * campo en absoluto, sin importar la capability del llamador. Es
	 * el puente de identidad con el LMS legado (CPT lm_course), no
	 * metadata decorativa: LMS_Enrollment_Service lo usa para resolver
	 * matrícula cuando atora_lms_read_source = tables, y el migrador
	 * lo consulta para decidir si un curso ya fue migrado.
	 *
	 * @param int $course_id
	 * @param int $wp_post_id
	 * @return array{ok:bool, reason?:string}
	 */
	public static function link_to_legacy_post( int $course_id, int $wp_post_id ): array {
		global $wpdb;

		if ( ! $course_id || ! $wp_post_id ) {
			return array( 'ok' => false, 'reason' => 'datos_invalidos' );
		}

		if ( 'lm_course' !== get_post_type( $wp_post_id ) ) {
			return array( 'ok' => false, 'reason' => 'no_es_lm_course' );
		}

		if ( ! current_user_can( 'edit_post', $wp_post_id ) ) {
			return array( 'ok' => false, 'reason' => 'sin_permiso_sobre_el_post' );
		}

		// PT-6 (6.5.5): antes solo se validaba el lado del post legado
		// (WP) — un método sin exponer todavía por un endpoint público,
		// pero seguro-por-diseño de cara a cualquier endpoint futuro:
		// también se exige permiso para administrar el curso Atora del
		// otro lado del vínculo, no solo el post de WP. Mismo criterio
		// jerárquico que LMS_REST_Controller::can_manage_this_course().
		if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'edit_others_lm_courses' ) ) {
			$course = self::get( $course_id );
			if ( ! $course ) {
				return array( 'ok' => false, 'reason' => 'curso_inexistente' );
			}
			$owns_course = current_user_can( 'clms_manage_courses' )
				&& (int) ( $course['instructor_id'] ?? 0 ) === get_current_user_id();
			if ( ! $owns_course ) {
				return array( 'ok' => false, 'reason' => 'sin_permiso_sobre_el_curso' );
			}
		}

		// Defensa en profundidad además del UNIQUE KEY de la tabla —
		// para devolver un error claro en vez de que el UPDATE falle
		// en seco por la restricción de base de datos.
		$existing = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}atora_courses WHERE wp_post_id = %d AND id != %d LIMIT 1",
				$wp_post_id,
				$course_id
			)
		);
		if ( $existing ) {
			return array( 'ok' => false, 'reason' => 'ya_vinculado_a_otro_curso' );
		}

		$updated = $wpdb->update(
			$wpdb->prefix . 'atora_courses',
			array( 'wp_post_id' => $wp_post_id ),
			array( 'id' => $course_id ),
			array( '%d' ),
			array( '%d' )
		);

		return array( 'ok' => false !== $updated );
	}

	// ── Lecciones ────────────────────────────────────────────────────────────

	public static function get_lessons( int $course_id ): array {
		global $wpdb;
		$rows = (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}atora_lessons
				 WHERE course_id = %d AND status = 'published'
				 ORDER BY section_order ASC, lesson_order ASC",
				$course_id
			),
			ARRAY_A
		);
		return array_map( array( __CLASS__, 'format_lesson' ), $rows );
	}

	public static function get_lesson( int $lesson_id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$wpdb->prefix}atora_lessons WHERE id = %d LIMIT 1", $lesson_id ),
			ARRAY_A
		);
		return $row ? self::format_lesson( $row ) : null;
	}

	public static function get_lesson_by_wp_post( int $wp_post_id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$wpdb->prefix}atora_lessons WHERE wp_post_id = %d LIMIT 1", $wp_post_id ),
			ARRAY_A
		);
		return $row ? self::format_lesson( $row ) : null;
	}

	public static function upsert_lesson( array $data ): int {
		global $wpdb;
		$row = self::sanitize_lesson_data( $data );
		if ( '' === ( $row['title'] ?? '' ) || ! ( $row['course_id'] ?? 0 ) ) { return 0; }

		$wp_post_id = absint( $data['wp_post_id'] ?? 0 );
		$existing   = $wp_post_id
			? (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}atora_lessons WHERE wp_post_id = %d LIMIT 1", $wp_post_id ) )
			: 0;

		if ( $existing ) {
			unset( $row['created_at'] );
			$wpdb->update( $wpdb->prefix . 'atora_lessons', $row, array( 'id' => $existing ), null, array( '%d' ) );
			return $existing;
		}

		$ok = $wpdb->insert( $wpdb->prefix . 'atora_lessons', $row );
		return $ok ? (int) $wpdb->insert_id : 0;
	}

	// ── Curriculum estructurado ───────────────────────────────────────────────

	public static function get_curriculum( int $course_id ): array {
		// Fase V S16: Object cache (Redis si disponible, WP default como fallback)
		$cache_key  = 'atora_curriculum_' . $course_id;
		$cache_group = 'atora_lms';
		$cached     = wp_cache_get( $cache_key, $cache_group );
		if ( false !== $cached && is_array( $cached ) ) {
			return $cached;
		}

		$lessons  = self::get_lessons( $course_id );
		$sections = array();

		foreach ( $lessons as $lesson ) {
			$section = $lesson['section'] ?: __( 'General', 'atora-lms' );
			if ( ! isset( $sections[ $section ] ) ) {
				$sections[ $section ] = array(
					'title'   => $section,
					'order'   => $lesson['section_order'],
					'lessons' => array(),
				);
			}
			$sections[ $section ]['lessons'][] = $lesson;
		}

		usort( $sections, fn( $a, $b ) => $a['order'] <=> $b['order'] );
		$curriculum = array_values( $sections );

		wp_cache_set( $cache_key, $curriculum, $cache_group, 300 ); // 5 minutos
		return $curriculum;
	}

	/**
	 * Invalida el cache del curriculum de un curso.
	 * Llamar tras actualizar lecciones.
	 *
	 * @param int $course_id ID del curso.
	 */
	public static function invalidate_curriculum_cache( int $course_id ): void {
		wp_cache_delete( 'atora_curriculum_' . $course_id, 'atora_lms' );
	}

	// ── Helpers de formato ───────────────────────────────────────────────────

	private static function format_course( array $row ): array {
		return array(
			'id'             => absint( $row['id'] ),
			'wp_post_id'     => absint( $row['wp_post_id'] ),
			'revision'       => absint( $row['revision'] ?? 1 ),
			'title'          => sanitize_text_field( (string) ( $row['title']          ?? '' ) ),
			'slug'           => sanitize_title(      (string) ( $row['slug']           ?? '' ) ),
			'excerpt'        => sanitize_textarea_field( (string) ( $row['excerpt']    ?? '' ) ),
			'status'         => sanitize_key(        (string) ( $row['status']         ?? 'draft' ) ),
			'type'           => sanitize_key(        (string) ( $row['type']           ?? 'self_paced' ) ),
			'instructor_id'  => absint(                        $row['instructor_id']   ?? 0 ),
			'price'          => (float)                       ( $row['price']          ?? 0 ),
			'currency'       => sanitize_key(        (string) ( $row['currency']       ?? 'USD' ) ),
			'duration_hours' => (float)                       ( $row['duration_hours'] ?? 0 ),
			'level'          => sanitize_key(        (string) ( $row['level']          ?? 'beginner' ) ),
			'language'       => sanitize_key(        (string) ( $row['language']       ?? 'es' ) ),
			'thumbnail_url'  => esc_url_raw(         (string) ( $row['thumbnail_url']  ?? '' ) ),
			'passing_grade'  => absint(                        $row['passing_grade']   ?? 70 ),
			'settings_json'  => json_decode( (string) ( $row['settings_json'] ?? '{}' ), true ) ?: array(),
			'meta_json'      => json_decode( (string) ( $row['meta_json']     ?? '{}' ), true ) ?: array(),
			'published_at'   => sanitize_text_field( (string) ( $row['published_at']   ?? '' ) ),
			'created_at'     => sanitize_text_field( (string) ( $row['created_at']     ?? '' ) ),
		);
	}

	private static function format_lesson( array $row ): array {
		return array(
			'id'              => absint( $row['id'] ),
			'wp_post_id'      => absint( $row['wp_post_id'] ),
			'course_id'       => absint( $row['course_id'] ),
			'title'           => sanitize_text_field( (string) ( $row['title']        ?? '' ) ),
			'slug'            => sanitize_title(      (string) ( $row['slug']         ?? '' ) ),
			'revision'        => absint( $row['revision'] ?? 1 ),
			'lesson_order'    => absint(                        $row['lesson_order']  ?? 0 ),
			'section'         => sanitize_text_field( (string) ( $row['section']      ?? '' ) ),
			'section_order'   => absint(                        $row['section_order'] ?? 0 ),
			'type'            => sanitize_key(        (string) ( $row['type']         ?? 'text' ) ),
			'duration_min'    => absint(                        $row['duration_min']  ?? 0 ),
			'is_free_preview' => (bool) ( $row['is_free_preview'] ?? false ),
			'is_required'     => (bool) ( $row['is_required']     ?? true ),
			'video_url'       => esc_url_raw( (string) ( $row['video_url'] ?? '' ) ),
			'status'          => sanitize_key( (string) ( $row['status'] ?? 'published' ) ),
			'created_at'      => sanitize_text_field( (string) ( $row['created_at'] ?? '' ) ),
		);
	}

	/** 6.27.4: misma normalización que al escribir, para comparar con la fila guardada. */
	public static function normalize_course_fields( array $d ): array {
		return self::sanitize_course_data( $d );
	}

	public static function normalize_lesson_fields( array $d ): array {
		return self::sanitize_lesson_data( $d );
	}

	private static function sanitize_course_data( array $d ): array {
		return array_filter( array(
			'wp_post_id'     => isset( $d['wp_post_id'] )     ? absint( $d['wp_post_id'] )                         : null,
			'title'          => isset( $d['title'] )          ? sanitize_text_field( (string) $d['title'] )        : null,
			'slug'           => isset( $d['slug'] )           ? sanitize_title( (string) $d['slug'] )              : null,
			'description'    => isset( $d['description'] )    ? wp_kses_post( (string) $d['description'] )         : null,
			'excerpt'        => isset( $d['excerpt'] )        ? sanitize_textarea_field( (string) $d['excerpt'] )  : null,
			'status'         => isset( $d['status'] )         ? sanitize_key( (string) $d['status'] )              : null,
			'type'           => isset( $d['type'] )           ? sanitize_key( (string) $d['type'] )                : null,
			'instructor_id'  => isset( $d['instructor_id'] )  ? absint( $d['instructor_id'] )                      : null,
			'price'          => isset( $d['price'] )          ? (float) $d['price']                                : null,
			'currency'       => isset( $d['currency'] )       ? sanitize_key( (string) $d['currency'] )            : null,
			'duration_hours' => isset( $d['duration_hours'] ) ? (float) $d['duration_hours']                       : null,
			'level'          => isset( $d['level'] )          ? sanitize_key( (string) $d['level'] )               : null,
			'language'       => isset( $d['language'] )       ? sanitize_key( (string) $d['language'] )            : null,
			'thumbnail_url'  => isset( $d['thumbnail_url'] )  ? esc_url_raw( (string) $d['thumbnail_url'] )        : null,
			'passing_grade'  => isset( $d['passing_grade'] )  ? absint( $d['passing_grade'] )                      : null,
			'settings_json'  => isset( $d['settings_json'] )  ? wp_json_encode( $d['settings_json'] )              : null,
			'meta_json'      => isset( $d['meta_json'] )      ? wp_json_encode( $d['meta_json'] )                  : null,
			'published_at'   => isset( $d['published_at'] )   ? sanitize_text_field( (string) $d['published_at'] ) : null,
		), fn( $v ) => $v !== null );
	}

	private static function sanitize_lesson_data( array $d ): array {
		return array_filter( array(
			'wp_post_id'      => isset( $d['wp_post_id'] )     ? absint( $d['wp_post_id'] )                       : null,
			'course_id'       => isset( $d['course_id'] )      ? absint( $d['course_id'] )                        : null,
			'title'           => isset( $d['title'] )          ? sanitize_text_field( (string) $d['title'] )      : null,
			'slug'            => isset( $d['slug'] )           ? sanitize_title( (string) $d['slug'] )            : null,
			'content'         => isset( $d['content'] )        ? wp_kses_post( (string) $d['content'] )           : null,
			'lesson_order'    => isset( $d['lesson_order'] )   ? absint( $d['lesson_order'] )                     : null,
			'section'         => isset( $d['section'] )        ? sanitize_text_field( (string) $d['section'] )   : null,
			'section_order'   => isset( $d['section_order'] )  ? absint( $d['section_order'] )                    : null,
			'type'            => isset( $d['type'] )           ? sanitize_key( (string) $d['type'] )              : null,
			'duration_min'    => isset( $d['duration_min'] )   ? absint( $d['duration_min'] )                     : null,
			'is_free_preview' => isset( $d['is_free_preview'] )? (int) (bool) $d['is_free_preview']               : null,
			'is_required'     => isset( $d['is_required'] )    ? (int) (bool) $d['is_required']                   : null,
			'video_url'       => isset( $d['video_url'] )      ? esc_url_raw( (string) $d['video_url'] )          : null,
			'status'          => isset( $d['status'] )         ? sanitize_key( (string) $d['status'] )            : null,
			'content_hash'    => isset( $d['content_hash'] ) && self::lessons_have_content_hash() ? preg_replace( '/[^a-f0-9]/', '', (string) $d['content_hash'] ) : null,
		), fn( $v ) => $v !== null );
	}

	/** 6.28.0: la columna llega con el esquema 6.28.0-sync-schema; antes de migrar no se escribe. */
	public static function lessons_have_content_hash(): bool {
		static $has = null;
		if ( null === $has ) {
			global $wpdb;
			$has = (bool) $wpdb->get_var( "SHOW COLUMNS FROM {$wpdb->prefix}atora_lessons LIKE 'content_hash'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		}
		return $has;
	}
}
